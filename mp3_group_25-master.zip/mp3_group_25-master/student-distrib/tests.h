// #ifndef TESTS_H
// #define TESTS_H


// // test launcher
// void launch_tests();


// int divideByZero();



// int invalidOpcodeS();

// int pagingTest();

// int DirTest();

// int FileReadTest();




// #endif /* TESTS_H */
