
#ifndef ASM

extern void setUpStack(uint8_t *  executable_eip); //for context switch from execute

#endif
