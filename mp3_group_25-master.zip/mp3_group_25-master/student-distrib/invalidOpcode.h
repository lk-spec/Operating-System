#ifndef ASM
extern void opcodeTest();
extern void segmentErrorCall();

#endif

