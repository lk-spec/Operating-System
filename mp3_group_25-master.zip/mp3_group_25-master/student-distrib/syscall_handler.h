
#ifndef ASM

extern void syscall_handler();
extern void halt_handler(int old_ebp, int old_esp, int status);

#endif
